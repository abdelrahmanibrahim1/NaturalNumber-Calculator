import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * Controller class.
 *
 * @author Abd Elrahman Ibrahim
 */
public final class NNCalcController1 implements NNCalcController {

    /**
     * Model object.
     */
    private final NNCalcModel model;

    /**
     * View object.
     */
    private final NNCalcView view;

    /**
     * Useful constants.
     */
    private static final NaturalNumber TWO = new NaturalNumber2(2),
            INT_LIMIT = new NaturalNumber2(Integer.MAX_VALUE);

    /**
     * Updates this.view to display this.model, and to allow only operations
     * that are legal given this.model.
     *
     * @param model
     *            the model
     * @param view
     *            the view
     * @ensures [view has been updated to be consistent with model]
     */
    private static void updateViewToMatchModel(NNCalcModel model,
            NNCalcView view) {

        /*
         * Getting the NaturalNumbers and the top and bottom text boxes
         */
        NaturalNumber top = model.top();
        NaturalNumber bottom = model.bottom();

        /*
         * Updating the views in the top and bottom text boxes to match the
         * model
         */
        view.updateTopDisplay(top);
        view.updateBottomDisplay(bottom);

    }

    /**
     * Constructor.
     *
     * @param model
     *            model to connect to
     * @param view
     *            view to connect to
     */
    public NNCalcController1(NNCalcModel model, NNCalcView view) {
        this.model = model;
        this.view = view;
        updateViewToMatchModel(model, view);
    }

    @Override
    public void processClearEvent() {
        /*
         * Get alias to bottom from model
         */
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        bottom.clear();

        /*
         * Updating the buttons that are allowed after the button is pressed
         */
        this.view.updateDivideAllowed(false);
        this.view.updateRootAllowed(false);
        this.view.updateSubtractAllowed(true);
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSwapEvent() {
        /*
         * Get aliases to top and bottom from model
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        NaturalNumber temp = top.newInstance();
        temp.transferFrom(top);
        top.transferFrom(bottom);
        bottom.transferFrom(temp);

        /*
         * Updating the buttons that are allowed after the button is pressed
         */
        if (!bottom.isZero()) {
            this.view.updateDivideAllowed(true);
        } else {
            this.view.updateDivideAllowed(false);
        }

        if (bottom.compareTo(TWO) >= 0) {
            if (bottom.compareTo(INT_LIMIT) < 0) {
                this.view.updateRootAllowed(true);
            } else {
                this.view.updateRootAllowed(false);
            }
        } else {
            this.view.updateRootAllowed(false);
        }

        if (bottom.compareTo(INT_LIMIT) > 0) {
            this.view.updatePowerAllowed(false);
        } else {
            this.view.updatePowerAllowed(true);
        }

        if (top.compareTo(bottom) < 0) {
            this.view.updateSubtractAllowed(false);
        } else {
            this.view.updateSubtractAllowed(true);
        }

        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processEnterEvent() {

        /*
         * Getting aliases to the top and the bottom NaturalNumbers in the model
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        top.copyFrom(bottom);

        /*
         * Updating the buttons that are allowed after the button is pressed
         */
        if (!bottom.isZero()) {
            this.view.updateDivideAllowed(true);
        } else {
            this.view.updateDivideAllowed(false);
        }

        if (bottom.compareTo(TWO) >= 0) {
            if (bottom.compareTo(INT_LIMIT) < 0) {
                this.view.updateRootAllowed(true);
            } else {
                this.view.updateRootAllowed(false);
            }
        } else {
            this.view.updateRootAllowed(false);
        }

        if (bottom.compareTo(INT_LIMIT) > 0) {
            this.view.updatePowerAllowed(false);
        } else {
            this.view.updatePowerAllowed(true);
        }

        if (top.compareTo(bottom) < 0) {
            this.view.updateSubtractAllowed(false);
        } else {
            this.view.updateSubtractAllowed(true);
        }

        /*
         * Updating the view to reflect the change in the model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processAddEvent() {

        /*
         * Getting aliases to the top and bottom NaturalNumbers in the model
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        bottom.add(top);
        top.clear();

        /*
         * Updating the buttons that are allowed after the button is pressed
         */
        if (!bottom.isZero()) {
            this.view.updateDivideAllowed(true);
        } else {
            this.view.updateDivideAllowed(false);
        }

        if (bottom.compareTo(TWO) >= 0) {
            if (bottom.compareTo(INT_LIMIT) < 0) {
                this.view.updateRootAllowed(true);
            } else {
                this.view.updateRootAllowed(false);
            }
        } else {
            this.view.updateRootAllowed(false);
        }

        if (bottom.compareTo(INT_LIMIT) > 0) {
            this.view.updatePowerAllowed(false);
        } else {
            this.view.updatePowerAllowed(true);
        }

        if (top.compareTo(bottom) < 0) {
            this.view.updateSubtractAllowed(false);
        } else {
            this.view.updateSubtractAllowed(true);
        }

        /*
         * Updating the view to reflect the changes to the model
         */
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processSubtractEvent() {

        /*
         * Getting aliases to the top and bottom NaturalNumbers
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        top.subtract(bottom);
        bottom.transferFrom(top);

        /*
         * Updating the buttons that are allowed after the button is pressed
         */
        if (!bottom.isZero()) {
            this.view.updateDivideAllowed(true);
        } else {
            this.view.updateDivideAllowed(false);
        }

        if (bottom.compareTo(TWO) >= 0) {
            if (bottom.compareTo(INT_LIMIT) < 0) {
                this.view.updateRootAllowed(true);
            } else {
                this.view.updateRootAllowed(false);
            }
        } else {
            this.view.updateRootAllowed(false);
        }

        if (bottom.compareTo(INT_LIMIT) > 0) {
            this.view.updatePowerAllowed(false);
        } else {
            this.view.updatePowerAllowed(true);
        }

        if (top.compareTo(bottom) < 0) {
            this.view.updateSubtractAllowed(false);
        } else {
            this.view.updateSubtractAllowed(true);
        }

        /*
         * Updating the view to reflect the changes in the model
         */
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processMultiplyEvent() {

        /*
         * Getting aliases to the top and bottom NaturalNumbers
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        bottom.multiply(top);
        top.clear();

        /*
         * Updating the buttons that are allowed after the button is pressed
         */
        if (!bottom.isZero()) {
            this.view.updateDivideAllowed(true);
        } else {
            this.view.updateDivideAllowed(false);
        }

        if (bottom.compareTo(TWO) >= 0) {
            if (bottom.compareTo(INT_LIMIT) < 0) {
                this.view.updateRootAllowed(true);
            } else {
                this.view.updateRootAllowed(false);
            }
        } else {
            this.view.updateRootAllowed(false);
        }

        if (bottom.compareTo(INT_LIMIT) > 0) {
            this.view.updatePowerAllowed(false);
        } else {
            this.view.updatePowerAllowed(true);
        }

        if (top.compareTo(bottom) < 0) {
            this.view.updateSubtractAllowed(false);
        } else {
            this.view.updateSubtractAllowed(true);
        }

        /*
         * Updating the view to reflect the changes in the model
         */
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processDivideEvent() {

        /*
         * Getting aliases for the top and bottom NaturalNumbers
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        /*
         * Dividing the top NaturalNumber by the bottom NaturalNumber, putting
         * the top NaturalNumber in the bottom text area, and putting the
         * remainder of the division in the top text area
         */
        NaturalNumber remainder = top.divide(bottom);
        bottom.transferFrom(top);
        top.transferFrom(remainder);

        /*
         * Updating the buttons that are allowed after the button is pressed
         */
        if (!bottom.isZero()) {
            this.view.updateDivideAllowed(true);
        } else {
            this.view.updateDivideAllowed(false);
        }

        if (bottom.compareTo(TWO) >= 0) {
            if (bottom.compareTo(INT_LIMIT) < 0) {
                this.view.updateRootAllowed(true);
            } else {
                this.view.updateRootAllowed(false);
            }
        } else {
            this.view.updateRootAllowed(false);
        }

        if (bottom.compareTo(INT_LIMIT) > 0) {
            this.view.updatePowerAllowed(false);
        } else {
            this.view.updatePowerAllowed(true);
        }

        if (top.compareTo(bottom) < 0) {
            this.view.updateSubtractAllowed(false);
        } else {
            this.view.updateSubtractAllowed(true);
        }

        /*
         * Updating the view to reflect the changes in the model
         */
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processPowerEvent() {

        /*
         * Getting aliases for the top and bottom NaturalNumbers
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        top.power(bottom.toInt());
        bottom.transferFrom(top);

        /*
         * Updating the buttons that are allowed after the button is pressed
         */
        if (!bottom.isZero()) {
            this.view.updateDivideAllowed(true);
        } else {
            this.view.updateDivideAllowed(false);
        }

        if (bottom.compareTo(TWO) >= 0) {
            if (bottom.compareTo(INT_LIMIT) < 0) {
                this.view.updateRootAllowed(true);
            } else {
                this.view.updateRootAllowed(false);
            }
        } else {
            this.view.updateRootAllowed(false);
        }

        if (bottom.compareTo(INT_LIMIT) > 0) {
            this.view.updatePowerAllowed(false);
        } else {
            this.view.updatePowerAllowed(true);
        }

        if (top.compareTo(bottom) < 0) {
            this.view.updateSubtractAllowed(false);
        } else {
            this.view.updateSubtractAllowed(true);
        }

        /*
         * Updating the view to reflect the changes to the model
         */
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processRootEvent() {

        /*
         * Getting aliases for the top and bottom NaturalNumbers
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        top.root(bottom.toInt());
        bottom.transferFrom(top);

        /*
         * Updating the buttons that are allowed after the button is pressed
         */
        if (!bottom.isZero()) {
            this.view.updateDivideAllowed(true);
        } else {
            this.view.updateDivideAllowed(false);
        }

        if (bottom.compareTo(TWO) >= 0) {
            if (bottom.compareTo(INT_LIMIT) < 0) {
                this.view.updateRootAllowed(true);
            } else {
                this.view.updateRootAllowed(false);
            }
        } else {
            this.view.updateRootAllowed(false);
        }

        if (bottom.compareTo(INT_LIMIT) > 0) {
            this.view.updatePowerAllowed(false);
        } else {
            this.view.updatePowerAllowed(true);
        }

        if (top.compareTo(bottom) < 0) {
            this.view.updateSubtractAllowed(false);
        } else {
            this.view.updateSubtractAllowed(true);
        }

        /*
         * Updating the view to reflect the changes made to the model
         */
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processAddNewDigitEvent(int digit) {

        /*
         * Getting aliases for the top and bottom NaturalNumbers
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        bottom.multiplyBy10(digit);

        /*
         * Updating the buttons that are allowed after the button is pressed
         */
        if (!bottom.isZero()) {
            this.view.updateDivideAllowed(true);
        } else {
            this.view.updateDivideAllowed(false);
        }

        if (bottom.compareTo(TWO) >= 0) {
            if (bottom.compareTo(INT_LIMIT) < 0) {
                this.view.updateRootAllowed(true);
            } else {
                this.view.updateRootAllowed(false);
            }
        } else {
            this.view.updateRootAllowed(false);
        }

        if (bottom.compareTo(INT_LIMIT) > 0) {
            this.view.updatePowerAllowed(false);
        } else {
            this.view.updatePowerAllowed(true);
        }

        if (top.compareTo(bottom) < 0) {
            this.view.updateSubtractAllowed(false);
        } else {
            this.view.updateSubtractAllowed(true);
        }

        /*
         * Updating the view to reflect the changes to the model
         */
        updateViewToMatchModel(this.model, this.view);

    }

}
